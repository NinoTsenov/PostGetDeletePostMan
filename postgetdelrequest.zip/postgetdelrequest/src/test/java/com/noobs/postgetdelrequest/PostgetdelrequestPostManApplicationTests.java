package com.noobs.postgetdelrequest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostgetdelrequestPostManApplicationTests {

	@Test
	void contextLoads() {
	}

}
