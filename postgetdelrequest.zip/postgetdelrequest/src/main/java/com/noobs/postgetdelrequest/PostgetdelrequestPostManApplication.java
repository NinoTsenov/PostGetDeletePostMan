package com.noobs.postgetdelrequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PostgetdelrequestPostManApplication {

	public static void main(String[] args) {
		SpringApplication.run(PostgetdelrequestPostManApplication.class, args);
	}

}
